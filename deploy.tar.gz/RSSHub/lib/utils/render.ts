export { default as Atom } from '@/views/atom';
export { default as json } from '@/views/json';
export { default as RSS } from '@/views/rss';
export { default as rss3 } from '@/views/rss3';
