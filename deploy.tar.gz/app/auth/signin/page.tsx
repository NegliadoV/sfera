import { auth, signIn } from '@/auth';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { SignInForm } from './SignInForm';

export default async function SignInPage({
  searchParams,
}: {
  searchParams: Promise<{ callbackUrl?: string; registered?: string; email?: string }>;
}) {
  let session = null;
  try {
    session = await auth();
  } catch {
    // invalid/old session cookie
  }
  if (session?.user) redirect('/universes');

  const params = await searchParams;
  const callbackUrl = params?.callbackUrl ?? '/';
  const hasGoogleOAuth =
    Boolean(process.env.AUTH_GOOGLE_ID) && Boolean(process.env.AUTH_GOOGLE_SECRET);
  const hasGitHubOAuth =
    Boolean(process.env.AUTH_GITHUB_ID) && Boolean(process.env.AUTH_GITHUB_SECRET);
  const hasOAuth = hasGoogleOAuth || hasGitHubOAuth;

  return (
    <div className="flex flex-col items-center justify-center min-h-[100dvh] w-full px-4 py-12">
      <div className="glass-panel w-full max-w-md p-8 sm:p-10 flex flex-col items-center">
        <h1 
          className="text-3xl font-bold mb-3 text-center w-full" 
          style={{ background: 'linear-gradient(135deg, var(--text-primary) 0%, var(--accent-primary) 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', letterSpacing: '-0.02em' }}
        >
          Вход в Ноосферу
        </h1>
        <p className="text-center mb-8" style={{ color: 'var(--text-secondary)' }}>
          {hasOAuth
            ? 'Войдите через Google или GitHub, либо по email и паролю.'
            : 'Войдите по email и паролю или используйте dev-вход.'}
        </p>

        {hasGoogleOAuth && (
          <form
            action={async () => {
              'use server';
              await signIn('google', { redirectTo: '/universes' });
            }}
            className="w-full mb-3"
            target="_top"
          >
            <button type="submit" className="glass-icon-btn w-full flex items-center justify-center py-3">
              <i className="fa-brands fa-google mr-3 text-lg" aria-hidden />
              <span>Войти через Google</span>
            </button>
          </form>
        )}
        {hasGitHubOAuth && (
          <form
            action={async () => {
              'use server';
              await signIn('github', { redirectTo: '/universes' });
            }}
            className="w-full mb-8"
            target="_top"
          >
            <button type="submit" className="glass-icon-btn w-full flex items-center justify-center py-3">
              <i className="fa-brands fa-github mr-3 text-lg" aria-hidden />
              <span>Войти через GitHub</span>
            </button>
          </form>
        )}

        <SignInForm callbackUrl={callbackUrl} defaultEmail={params?.email ?? ''} />

        {params?.registered === '1' && (
          <p className="mt-4 text-sm" style={{ color: 'var(--studio-status-live-color)' }}>
            Вы зарегистрированы. Войдите с вашим email и паролем.
          </p>
        )}

        <p className="mt-8 text-sm" style={{ color: 'var(--text-muted)' }}>
          Нет аккаунта?{' '}
          <Link href="/auth/register" className="font-semibold transition-colors duration-200" style={{ color: 'var(--accent-primary)' }}>
            Зарегистрироваться
          </Link>
        </p>

        <div className="w-full mt-8 pt-6 flex flex-col items-center" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
          <p className="text-sm font-medium mb-4" style={{ color: 'var(--text-muted)' }}>Dev: вход как seed-пользователь</p>
          <form
            className="w-full"
            action={async () => {
              'use server';
              await signIn('credentials', {
                email: 'seed@horizon.local',
                password: 'dev',
                redirectTo: callbackUrl,
              });
            }}
          >
            <button type="submit" className="glass-icon-btn w-full flex items-center justify-center py-3">
              Войти как seed-пользователь
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
