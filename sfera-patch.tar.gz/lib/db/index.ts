import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from './schema';

const connectionString =
  process.env.DATABASE_URL ?? 'postgres://horizon:horizon_dev@localhost:5432/horizon';

const client = postgres(connectionString, { max: 10 });
export const db = drizzle(client, { schema });
export * from './schema';
